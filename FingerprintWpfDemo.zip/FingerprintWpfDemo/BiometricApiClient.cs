﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace FingerprintWpfDemo
{
    public class BiometricApiClient : IDisposable
    {
        private readonly HttpClient _httpClient;
        private bool _cfHeadersInitialised;

        // Base API URL
        private const string BASE_URL = "https://biometric.grosvenorhsc.org";

        // Cloudflare Access credentials
        private const string CF_ACCESS_CLIENT_ID = "07e1266722cc377abd861ae3ebd91ea8.access";
        private const string CF_ACCESS_CLIENT_SECRET = "baddeac1d9e0179750eaff34fdf34a10f3c8b25b7e35147b21041fab9c5e9e0b";

        // API auth
        private const string API_TOKEN = "aB1cD2eF3gH4iJ5kL6mN7oP8qR9sT0uVwXyZabCdefG=";
        private const string HMAC_SECRET_BASE64 = "Y/gB1XfDubCDGpZprcl9HPR7KKKcuWqd89QBF/vCSEEy3u89orIS/e0shpA2+CwsoqpFvyUySEaLS2XHS/z0+g==";

        public BiometricApiClient()
        {
            _httpClient = new HttpClient
            {
                Timeout = TimeSpan.FromSeconds(10)
            };
        }

        private void EnsureCloudflareHeaders()
        {
            if (_cfHeadersInitialised) return;

            _httpClient.DefaultRequestHeaders.Add("CF-Access-Client-Id", CF_ACCESS_CLIENT_ID);
            _httpClient.DefaultRequestHeaders.Add("CF-Access-Client-Secret", CF_ACCESS_CLIENT_SECRET);

            _cfHeadersInitialised = true;
        }

        // ---------- HEALTH CHECK ----------

        public async Task<string> GetHealthStatusTextAsync()
        {
            EnsureCloudflareHeaders();

            try
            {
                var resp = await _httpClient.GetAsync(BASE_URL + "/health");
                if (resp.IsSuccessStatusCode)
                {
                    return "API: OK";
                }

                return string.Format("API: error {0} {1}", (int)resp.StatusCode, resp.ReasonPhrase);
            }
            catch
            {
                return "API: unreachable";
            }
        }

        // ---------- ENROL REQUEST ----------

        private static string BytesToHexLower(byte[] bytes)
        {
            var sb = new StringBuilder(bytes.Length * 2);
            foreach (var b in bytes)
            {
                sb.Append(b.ToString("x2")); // lowercase hex
            }
            return sb.ToString();
        }

        private void AddSignedHeaders(HttpRequestMessage req, byte[] bodyBytes, string method, string path)
        {
            // 1) Timestamp
            string timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString();

            // 2) Body hash (hex sha256)
            string bodyHash;
            using (var sha = SHA256.Create())
            {
                var hashBytes = sha.ComputeHash(bodyBytes);
                bodyHash = BytesToHexLower(hashBytes);
            }

            // 3) Message
            string message = string.Format("{0}\n{1}\n{2}\n{3}",
                timestamp,
                method.ToUpperInvariant(),
                path,
                bodyHash);

            // 4) HMAC
            byte[] keyBytes = Convert.FromBase64String(HMAC_SECRET_BASE64);
            byte[] msgBytes = Encoding.UTF8.GetBytes(message);
            byte[] hmacBytes;
            using (var hmac = new HMACSHA256(keyBytes))
            {
                hmacBytes = hmac.ComputeHash(msgBytes);
            }

            string signature = Convert.ToBase64String(hmacBytes);

            // 5) Headers
            req.Headers.Remove("X-Api-Token");
            req.Headers.Remove("X-HMAC-Timestamp");
            req.Headers.Remove("X-HMAC-Signature");

            req.Headers.Add("X-Api-Token", API_TOKEN);
            req.Headers.Add("X-HMAC-Timestamp", timestamp);
            req.Headers.Add("X-HMAC-Signature", signature);
        }

        public class EnrolRequestDto
        {
            public string siteId { get; set; }
            public string deviceId { get; set; }
            public string employeeName { get; set; }
            public string templateBase64 { get; set; }
            public string clientLocalTime { get; set; }
        }

        public class EnrolResponseDto
        {
            public int enrollmentId { get; set; }
            public string enrollmentIdFormatted { get; set; }
            public string employeeRef { get; set; }
            public string status { get; set; }
        }

        /// <summary>
        /// Call /api/enrol with a template.
        /// Returns (Success, Response, Error). If Success is false, Response will be null and Error will be set.
        /// </summary>
        public async Task<(bool Success, EnrolResponseDto Response, string Error)> EnrolAsync(
            string siteId,
            string deviceId,
            string employeeName,
            string templateBase64)
        {
            EnsureCloudflareHeaders();

            var payload = new EnrolRequestDto
            {
                siteId = siteId,
                deviceId = deviceId,
                employeeName = employeeName,
                templateBase64 = templateBase64,
                clientLocalTime = DateTime.Now.ToString("o")
            };

            string json = JsonConvert.SerializeObject(payload);
            byte[] bodyBytes = Encoding.UTF8.GetBytes(json);

            string path = "/api/enrol";

            var req = new HttpRequestMessage(HttpMethod.Post, BASE_URL + path)
            {
                Content = new ByteArrayContent(bodyBytes)
            };
            req.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            AddSignedHeaders(req, bodyBytes, "POST", path);

            try
            {
                var resp = await _httpClient.SendAsync(req);
                var respBody = await resp.Content.ReadAsStringAsync();

                if (!resp.IsSuccessStatusCode)
                {
                    string err = string.Format("HTTP {0} {1}: {2}",
                        (int)resp.StatusCode, resp.ReasonPhrase, respBody);
                    return (false, null, err);
                }

                var dto = JsonConvert.DeserializeObject<EnrolResponseDto>(respBody);
                if (dto == null)
                {
                    return (false, null, "Empty/invalid JSON response.");
                }

                return (true, dto, null);
            }
            catch (Exception ex)
            {
                return (false, null, ex.Message);
            }
        }

        public void Dispose()
        {
            _httpClient.Dispose();
        }
    }
}
