﻿using System;
using System.Threading.Tasks;
using System.Windows;

namespace FingerprintWpfDemo
{
    public partial class EnrollWindow : Window
    {
        private readonly FingerprintService _service;
        private readonly BiometricApiClient _api;

        // Adjust these for your real deployment
        private const string SITE_ID = "SITE-001";
        private static readonly string DEVICE_ID = Environment.MachineName;

        public EnrollWindow(FingerprintService service, BiometricApiClient api)
        {
            InitializeComponent();
            _service = service;
            _api = api;
        }

        private void AppendLog(string text)
        {
            txtLog.AppendText(text + "\r\n");
            txtLog.ScrollToEnd();
        }

        private async void btnEnrol_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                AppendLog("Enter a name to enrol.");
                return;
            }

            if (_service.HasTemplate(name))
            {
                AppendLog($"'{name}' already has a local template. Use Re-enrol.");
                return;
            }

            AppendLog($"Starting local enrolment for '{name}'...");

            btnEnrol.IsEnabled = false;
            btnReEnrol.IsEnabled = false;

            bool localOk = false;

            // Local enrolment on background thread
            await Task.Run(() =>
            {
                localOk = _service.Enrol(name, msg =>
                {
                    Dispatcher.Invoke(() => AppendLog(msg));
                });
            });

            if (!localOk)
            {
                AppendLog($"Local enrolment FAILED for '{name}'.");
                btnEnrol.IsEnabled = true;
                btnReEnrol.IsEnabled = true;
                return;
            }

            AppendLog($"Local enrolment COMPLETE for '{name}'.");
            AppendLog("Serialising template and sending to server...");

            await SendTemplateToServer(name);

            btnEnrol.IsEnabled = true;
            btnReEnrol.IsEnabled = true;
        }

        private async void btnReEnrol_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text.Trim();
            if (string.IsNullOrWhiteSpace(name))
            {
                AppendLog("Enter a name to re-enrol.");
                return;
            }

            if (!_service.HasTemplate(name))
            {
                AppendLog($"No existing local template found for '{name}'. Enrol as new.");
                return;
            }

            var result = MessageBox.Show(
                $"Replace the existing template for '{name}' and update it on the server?",
                "Confirm re-enrol",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result != MessageBoxResult.Yes)
            {
                AppendLog("Re-enrolment cancelled.");
                return;
            }

            AppendLog($"Re-enrolling '{name}' locally...");

            btnEnrol.IsEnabled = false;
            btnReEnrol.IsEnabled = false;

            bool localOk = false;

            await Task.Run(() =>
            {
                localOk = _service.Enrol(name, msg =>
                {
                    Dispatcher.Invoke(() => AppendLog(msg));
                });
            });

            if (!localOk)
            {
                AppendLog($"Local re-enrolment FAILED for '{name}'.");
                btnEnrol.IsEnabled = true;
                btnReEnrol.IsEnabled = true;
                return;
            }

            AppendLog($"Local re-enrolment COMPLETE for '{name}'.");
            AppendLog("Serialising template and sending updated template to server...");

            await SendTemplateToServer(name);

            btnEnrol.IsEnabled = true;
            btnReEnrol.IsEnabled = true;
        }

        private async Task SendTemplateToServer(string name)
        {
            var bytes = _service.GetTemplateBytes(name, msg => AppendLog(msg));
            if (bytes == null)
            {
                AppendLog("Cannot send to server: failed to get template bytes.");
                return;
            }

            string templateBase64 = Convert.ToBase64String(bytes);

            var result = await _api.EnrolAsync(
                SITE_ID,
                DEVICE_ID,
                name,
                templateBase64);

            if (result.Success && result.Response != null)
            {
                var resp = result.Response;
                AppendLog(string.Format("Server enrol OK. EnrollmentId: {0}, EmployeeRef: {1}, Status: {2}",
                    resp.enrollmentIdFormatted, resp.employeeRef, resp.status));
                _service.SetEnrollmentId(name, resp.enrollmentId);
            }
            else
            {
                AppendLog("Server enrol FAILED: " + result.Error);
            }
        }
    }
}
